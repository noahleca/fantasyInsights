﻿using Fantasy_Insights.Modelo;
using Fantasy_Insights.Vista;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fantasy_Insights.Controlador
{
    public class ControladorMejoresJugadoresBaratos
    {
        static FormMejoresJugadoresBaratos f = new FormMejoresJugadoresBaratos();
        Repository r = new Repository();
        private string filtroActual = f.comboBoxFiltro.Text;
        public string filtroSecundarioActual = f.comboBoxFiltroSecundario.Text;
        private const int PageSize = 50;
        private int currentPage = 0;
        private int totalPages = 0;
        public ControladorMejoresJugadoresBaratos(Panel panel)
        {
            load2Filtro();
            load2FiltroSecundario();
            load2Tabla(filtroActual, filtroSecundarioActual);
            initListeners();
            loadForm(panel);
        }
        void loadForm(Panel panel)
        {
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            panel.Controls.Add(f);
            panel.Tag = f;
            f.Show();
        }
        void initListeners()
        {
            f.comboBoxFiltro.SelectedIndexChanged += ComboBoxFiltro_SelectedIndexChanged;
            f.comboBoxFiltroSecundario.SelectedIndexChanged += ComboBoxFiltroSecundario_SelectedIndexChanged; 
            f.buttonAtras.Click += ButtonAtras_Click;
            f.buttonAdelante.Click += ButtonAdelante_Click;
        }

        private void ComboBoxFiltroSecundario_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtroActual = f.comboBoxFiltro.Text;
            filtroSecundarioActual = f.comboBoxFiltroSecundario.Text;
            switch (filtroActual)
            {
                case "Nombre":
                    load2Tabla("nombreJugador", filtroSecundarioActual);
                    break;
                case "Equipo":
                    load2Tabla("nombreEquipo", filtroSecundarioActual);
                    break;
                case "Posicion":
                    load2Tabla("posicionJugador", filtroSecundarioActual);
                    break;
                case "Puntos":
                    load2Tabla("puntosTotales", filtroSecundarioActual);
                    break;
                case "Promedio":
                    load2Tabla("puntosPromedio", filtroSecundarioActual);
                    break;
                case "Valor":
                    load2Tabla("valorMercadoReciente", filtroSecundarioActual);
                    break;
            }
        }
        void load2Filtro()
        {
            List<string> list = new List<string> { "Nombre", "Equipo", "Posicion", "Puntos", "Promedio", "Valor" };
            f.comboBoxFiltro.DataSource = list;
            f.comboBoxFiltro.SelectedIndex = 1;
        }
        void load2FiltroSecundario()
        {
            List<string> list = new List<string>();
            list.Add("-");
            list.AddRange(r.GetNombreEquipos());

            f.comboBoxFiltroSecundario.DataSource = list;
            filtroActual = f.comboBoxFiltro.Text;
            filtroSecundarioActual = f.comboBoxFiltroSecundario.Text;
        }
        private void ButtonAdelante_Click(object sender, EventArgs e)
        {
            LoadNextPage();
        }

        private void ButtonAtras_Click(object sender, EventArgs e)
        {
            LoadPreviousPage();
        }
        private void ComboBoxFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtroActual = f.comboBoxFiltro.Text;
            filtroSecundarioActual = f.comboBoxFiltroSecundario.Text;
            switch (filtroActual)
            {
                case "Nombre":
                    load2Tabla("nombreJugador", filtroSecundarioActual);
                    break;
                case "Equipo":
                    load2Tabla("nombreEquipo", filtroSecundarioActual);
                    break;
                case "Posicion":
                    load2Tabla("posicionJugador", filtroSecundarioActual);
                    break;
                case "Puntos":
                    load2Tabla("puntosTotales", filtroSecundarioActual);
                    break;
                case "Promedio":
                    load2Tabla("puntosPromedio", filtroSecundarioActual);
                    break;
                case "Valor":
                    load2Tabla("valorMercadoReciente", filtroSecundarioActual);
                    break;
            }
        }
        void load2Tabla(string filtro, string filtroSecundario)
        {
            filtroActual = filtro;
            filtroSecundarioActual = filtroSecundario;

            var totalPlayers = r.GetMejoresJugadoresBaratosFiltrados(filtroActual, filtroSecundarioActual).Count;
            totalPages = (totalPlayers + PageSize - 1) / PageSize;

            if (currentPage >= totalPages)
            {
                currentPage = totalPages - 1;
            }

            var jugadoresFiltrados = r.GetMejoresJugadoresBaratosFiltrados(filtroActual, filtroSecundarioActual)
                                      .Skip(currentPage * PageSize)
                                      .Take(PageSize)
                                      .ToList();

            f.dataGridViewMejoresJugadores.DataSource = jugadoresFiltrados;
            f.dataGridViewMejoresJugadores.Columns[0].HeaderText = "Nombre";
            f.dataGridViewMejoresJugadores.Columns[1].HeaderText = "Equipo";
            f.dataGridViewMejoresJugadores.Columns[2].HeaderText = "Posicion";
            f.dataGridViewMejoresJugadores.Columns[3].HeaderText = "Puntos";
            f.dataGridViewMejoresJugadores.Columns[4].HeaderText = "Promedio";
            f.dataGridViewMejoresJugadores.Columns[5].HeaderText = "Valor";
            f.dataGridViewMejoresJugadores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            f.dataGridViewMejoresJugadores.AutoResizeColumns();
        }
        private void LoadNextPage()
        {
            if (currentPage < totalPages - 1)
            {
                currentPage++;
                load2Tabla(filtroActual, filtroSecundarioActual);
            }
        }

        private void LoadPreviousPage()
        {
            if (currentPage > 0)
            {
                currentPage--;
                load2Tabla(filtroActual, filtroSecundarioActual);
            }
        }
        public FormMejoresJugadoresBaratos GetFormMejoresJugadoresBaratos()
        {
            return f;
        }
    }
}

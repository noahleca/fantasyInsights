﻿using Fantasy_Insights.Modelo;
using Fantasy_Insights.Vista;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fantasy_Insights.Controlador
{
    public class ControladorPrincipal
    {
        FormPrincipal f = new FormPrincipal();
        Repository r = new Repository();
        bool generalSubMenuOpened = false;
        bool tusLigasSubMenuOpened = false;
        public ControladorPrincipal()
        {
            f = new FormPrincipal();
            r = new Repository();
            InitListeners();
            Application.Run(f);
        }
        void InitListeners()
        {
            f.btnGeneral.Click += BtnGeneral_Click;
            f.btnMejoresJugadores.Click += BtnMejoresJugadores_Click;
            f.btnMejoresJugadoresBaratos.Click += BtnMejoresJugadoresBaratos_Click;
            f.btnOnceIdealJornada.Click += BtnOnceIdealJornada_Click;
            f.btnOnceIdealTemporada.Click += BtnOnceIdealTemporada_Click;
            f.btnCalculadoraOfertas.Click += BtnCalculadoraOfertas_Click;

            f.btnTusLigas.Click += BtnTusLigas_Click;
            f.btnLiga1.Click += BtnLiga1_Click;
            f.btnLiga2.Click += BtnLiga2_Click;

            f.btnLiga1EquiposEnemigos.Click += BtnLiga1EquiposEnemigos_Click;
            f.btnLiga1TuEquipo.Click += BtnLiga1TuEquipo_Click;
            f.btnLiga1Mercado.Click += BtnLiga1Mercado_Click;

            f.btnLiga2EquiposEnemigos.Click += BtnLiga2EquiposEnemigos_Click;
            f.btnLiga2TuEquipo.Click += BtnLiga2TuEquipo_Click;
            f.btnLiga2Mercado.Click += BtnLiga2Mercado_Click;
        }
        #region btn general
        private void BtnGeneral_Click(object sender, EventArgs e)
        {
            if (!generalSubMenuOpened)
            {
                showSubMenu(f.panelGeneralSubmenu);
                generalSubMenuOpened = true;
                tusLigasSubMenuOpened = false;
            }
            else
            {
                hideSubMenu();
                generalSubMenuOpened = false;
            }
        }
        private void BtnMejoresJugadores_Click(object sender, EventArgs e)
        {
            openChildForm(new ControladorMejoresJugadores(f.panelChildForm));
            hideSubMenu();
            generalSubMenuOpened = false;
        }
        private void BtnMejoresJugadoresBaratos_Click(object sender, EventArgs e)
        {
            openChildForm(new ControladorMejoresJugadoresBaratos(f.panelChildForm));
            hideSubMenu();
            generalSubMenuOpened = false;
        }
        private void BtnOnceIdealJornada_Click(object sender, EventArgs e)
        {
            openChildForm(new ControladorMejorAlineacionJornada(f.panelChildForm));
            hideSubMenu();
            generalSubMenuOpened = false;
        }
        private void BtnOnceIdealTemporada_Click(object sender, EventArgs e)
        {
            openChildForm(new ControladorMejorAlineacionTemporada(f.panelChildForm));
            hideSubMenu();
            generalSubMenuOpened = false;
        }
        private void BtnCalculadoraOfertas_Click(object sender, EventArgs e)
        {
            hideSubMenu();
            generalSubMenuOpened = false;
        }
        #endregion
        #region btn tus ligas
        private void BtnTusLigas_Click(object sender, EventArgs e)
        {
            if (!tusLigasSubMenuOpened)
            {
                showSubMenu(f.panelTusLigasSubmenu);
                tusLigasSubMenuOpened = true;
                generalSubMenuOpened = false;
            }
            else
            {
                hideSubMenu();
                tusLigasSubMenuOpened = false;
            }
        }
        #region btn liga 1
        private void BtnLiga1_Click(object sender, EventArgs e)
        {
            showSubSubMenu(f.panelTusLigasSubmenu, f.panelLiga1Submenu);
        }
        private void BtnLiga1EquiposEnemigos_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        private void BtnLiga1TuEquipo_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        private void BtnLiga1Mercado_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        #endregion
        #region btn liga 2
        private void BtnLiga2_Click(object sender, EventArgs e)
        {
            showSubSubMenu(f.panelTusLigasSubmenu, f.panelLiga2Submenu);
        }
        private void BtnLiga2EquiposEnemigos_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        private void BtnLiga2TuEquipo_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        private void BtnLiga2Mercado_Click(object sender, EventArgs e)
        {
            //..
            hideSubMenu();
        }
        #endregion
        #endregion
        #region hide and show submenu
        private void hideSubMenu()
        {

            if (f.panelGeneralSubmenu.Visible == true)
            {
                f.panelGeneralSubmenu.Visible = false;
            }
            if (f.panelTusLigasSubmenu.Visible == true)
            {
                f.panelTusLigasSubmenu.Visible = false;
            }
            if (f.panelLiga1Submenu.Visible == true)
            {
                f.panelLiga1Submenu.Visible = false;
            }
            if (f.panelLiga2Submenu.Visible == true)
            {
                f.panelLiga2Submenu.Visible = false;
            }
        }
        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }
        private void showSubSubMenu(Panel subMenu, Panel subSubMenu)
        {
            if (subSubMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
                subSubMenu.Visible = true;
            }
            else
            {
                subSubMenu.Visible = false;
            }
        }
        #endregion

        private Form activeForm =  null;
        private void openChildForm(ControladorMejoresJugadores c)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            Form childForm = c.GetFormMejoresJugadores(); // Suponiendo que c.f contiene la instancia de FormMejoresJugadores

            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            f.panelChildForm.Controls.Add(childForm);
            f.panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();


        }

        private void openChildForm(ControladorMejorAlineacionTemporada c)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            Form childForm = c.GetFormMejorAlineacionTemporada(); // Suponiendo que c.f contiene la instancia de FormMejoresJugadores

            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            f.panelChildForm.Controls.Add(childForm);
            f.panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();


        }

        private void openChildForm(ControladorMejorAlineacionJornada c)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            Form childForm = c.GetFormMejorAlineacionJornada(); // Suponiendo que c.f contiene la instancia de FormMejoresJugadores

            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            f.panelChildForm.Controls.Add(childForm);
            f.panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();


        }
        private void openChildForm(ControladorMejoresJugadoresBaratos c)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            Form childForm = c.GetFormMejoresJugadoresBaratos(); // Suponiendo que c.f contiene la instancia de FormMejoresJugadores

            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            f.panelChildForm.Controls.Add(childForm);
            f.panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();


        }
    }
}

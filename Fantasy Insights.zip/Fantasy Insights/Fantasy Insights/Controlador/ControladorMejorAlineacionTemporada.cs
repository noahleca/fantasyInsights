﻿using Fantasy_Insights.Modelo;
using Fantasy_Insights.Vista;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fantasy_Insights.Controlador
{
    public class ControladorMejorAlineacionTemporada
    {
        static FormMejorAlineacionTemporada f = new FormMejorAlineacionTemporada();
        Repository r = new Repository();
        List<playerMAT> alineacion = new List<playerMAT>();
        public ControladorMejorAlineacionTemporada(Panel panel)
        {
            alineacion = r.GetPlayersMAT();
            load2Tabla();
            loadForm(panel);
        }
        void loadForm(Panel panel)
        {
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            panel.Controls.Add(f);
            panel.Tag = f;
            f.Show();
        }
        void load2Tabla()
        {
            int puntos = (int)r.GetPlayersMAT().Sum(p => p.puntos);
            f.labelPuntos.Text = "Puntos totales: " + puntos + " puntos.";
            int valor = (int)r.GetPlayersMAT().Sum(p => p.valor);
            string valorFormateado = string.Format("{0:N0}", valor);
            f.labelValor.Text = "Valor del equipo: " + valorFormateado + "€.";
            f.dataGridViewMejoresJugadores.DataSource = r.GetPlayersMAT();
            f.dataGridViewMejoresJugadores.Columns[0].HeaderText = "Nombre";
            f.dataGridViewMejoresJugadores.Columns[1].HeaderText = "Equipo";
            f.dataGridViewMejoresJugadores.Columns[2].HeaderText = "Posicion";
            f.dataGridViewMejoresJugadores.Columns[3].HeaderText = "Valor";
            f.dataGridViewMejoresJugadores.Columns[4].HeaderText = "Puntos";
            f.dataGridViewMejoresJugadores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            f.dataGridViewMejoresJugadores.AutoResizeColumns();
        }

        public FormMejorAlineacionTemporada GetFormMejorAlineacionTemporada()
        {
            return f;
        }
    }
}

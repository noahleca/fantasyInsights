﻿namespace Fantasy_Insights.Vista
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelTusLigasSubmenu = new System.Windows.Forms.Panel();
            this.panelLiga2Submenu = new System.Windows.Forms.Panel();
            this.btnLiga2Mercado = new System.Windows.Forms.Button();
            this.btnLiga2TuEquipo = new System.Windows.Forms.Button();
            this.btnLiga2EquiposEnemigos = new System.Windows.Forms.Button();
            this.btnLiga2 = new System.Windows.Forms.Button();
            this.panelLiga1Submenu = new System.Windows.Forms.Panel();
            this.btnLiga1Mercado = new System.Windows.Forms.Button();
            this.btnLiga1TuEquipo = new System.Windows.Forms.Button();
            this.btnLiga1EquiposEnemigos = new System.Windows.Forms.Button();
            this.btnLiga1 = new System.Windows.Forms.Button();
            this.btnTusLigas = new System.Windows.Forms.Button();
            this.panelGeneralSubmenu = new System.Windows.Forms.Panel();
            this.btnCalculadoraOfertas = new System.Windows.Forms.Button();
            this.btnOnceIdealTemporada = new System.Windows.Forms.Button();
            this.btnOnceIdealJornada = new System.Windows.Forms.Button();
            this.btnMejoresJugadoresBaratos = new System.Windows.Forms.Button();
            this.btnMejoresJugadores = new System.Windows.Forms.Button();
            this.btnGeneral = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.panelSideMenu.SuspendLayout();
            this.panelTusLigasSubmenu.SuspendLayout();
            this.panelLiga2Submenu.SuspendLayout();
            this.panelLiga1Submenu.SuspendLayout();
            this.panelGeneralSubmenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.AutoScroll = true;
            this.panelSideMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panelSideMenu.Controls.Add(this.panelTusLigasSubmenu);
            this.panelSideMenu.Controls.Add(this.btnTusLigas);
            this.panelSideMenu.Controls.Add(this.panelGeneralSubmenu);
            this.panelSideMenu.Controls.Add(this.btnGeneral);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(250, 561);
            this.panelSideMenu.TabIndex = 0;
            // 
            // panelTusLigasSubmenu
            // 
            this.panelTusLigasSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelTusLigasSubmenu.Controls.Add(this.panelLiga2Submenu);
            this.panelTusLigasSubmenu.Controls.Add(this.btnLiga2);
            this.panelTusLigasSubmenu.Controls.Add(this.panelLiga1Submenu);
            this.panelTusLigasSubmenu.Controls.Add(this.btnLiga1);
            this.panelTusLigasSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTusLigasSubmenu.Location = new System.Drawing.Point(0, 421);
            this.panelTusLigasSubmenu.Name = "panelTusLigasSubmenu";
            this.panelTusLigasSubmenu.Size = new System.Drawing.Size(233, 419);
            this.panelTusLigasSubmenu.TabIndex = 4;
            // 
            // panelLiga2Submenu
            // 
            this.panelLiga2Submenu.Controls.Add(this.btnLiga2Mercado);
            this.panelLiga2Submenu.Controls.Add(this.btnLiga2TuEquipo);
            this.panelLiga2Submenu.Controls.Add(this.btnLiga2EquiposEnemigos);
            this.panelLiga2Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLiga2Submenu.Location = new System.Drawing.Point(0, 230);
            this.panelLiga2Submenu.Name = "panelLiga2Submenu";
            this.panelLiga2Submenu.Size = new System.Drawing.Size(233, 140);
            this.panelLiga2Submenu.TabIndex = 5;
            // 
            // btnLiga2Mercado
            // 
            this.btnLiga2Mercado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga2Mercado.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga2Mercado.FlatAppearance.BorderSize = 0;
            this.btnLiga2Mercado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga2Mercado.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga2Mercado.Location = new System.Drawing.Point(0, 90);
            this.btnLiga2Mercado.Name = "btnLiga2Mercado";
            this.btnLiga2Mercado.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga2Mercado.Size = new System.Drawing.Size(233, 44);
            this.btnLiga2Mercado.TabIndex = 5;
            this.btnLiga2Mercado.Text = "Mercado";
            this.btnLiga2Mercado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga2Mercado.UseVisualStyleBackColor = false;
            // 
            // btnLiga2TuEquipo
            // 
            this.btnLiga2TuEquipo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga2TuEquipo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga2TuEquipo.FlatAppearance.BorderSize = 0;
            this.btnLiga2TuEquipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga2TuEquipo.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga2TuEquipo.Location = new System.Drawing.Point(0, 45);
            this.btnLiga2TuEquipo.Name = "btnLiga2TuEquipo";
            this.btnLiga2TuEquipo.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga2TuEquipo.Size = new System.Drawing.Size(233, 45);
            this.btnLiga2TuEquipo.TabIndex = 4;
            this.btnLiga2TuEquipo.Text = "Tu equipo";
            this.btnLiga2TuEquipo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga2TuEquipo.UseVisualStyleBackColor = false;
            // 
            // btnLiga2EquiposEnemigos
            // 
            this.btnLiga2EquiposEnemigos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga2EquiposEnemigos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga2EquiposEnemigos.FlatAppearance.BorderSize = 0;
            this.btnLiga2EquiposEnemigos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga2EquiposEnemigos.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga2EquiposEnemigos.Location = new System.Drawing.Point(0, 0);
            this.btnLiga2EquiposEnemigos.Name = "btnLiga2EquiposEnemigos";
            this.btnLiga2EquiposEnemigos.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga2EquiposEnemigos.Size = new System.Drawing.Size(233, 45);
            this.btnLiga2EquiposEnemigos.TabIndex = 3;
            this.btnLiga2EquiposEnemigos.Text = "Equipos enemigos";
            this.btnLiga2EquiposEnemigos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga2EquiposEnemigos.UseVisualStyleBackColor = false;
            // 
            // btnLiga2
            // 
            this.btnLiga2.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga2.FlatAppearance.BorderSize = 0;
            this.btnLiga2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga2.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga2.Location = new System.Drawing.Point(0, 185);
            this.btnLiga2.Name = "btnLiga2";
            this.btnLiga2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnLiga2.Size = new System.Drawing.Size(233, 45);
            this.btnLiga2.TabIndex = 4;
            this.btnLiga2.Text = "Liga 2";
            this.btnLiga2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga2.UseVisualStyleBackColor = true;
            // 
            // panelLiga1Submenu
            // 
            this.panelLiga1Submenu.Controls.Add(this.btnLiga1Mercado);
            this.panelLiga1Submenu.Controls.Add(this.btnLiga1TuEquipo);
            this.panelLiga1Submenu.Controls.Add(this.btnLiga1EquiposEnemigos);
            this.panelLiga1Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLiga1Submenu.Location = new System.Drawing.Point(0, 45);
            this.panelLiga1Submenu.Name = "panelLiga1Submenu";
            this.panelLiga1Submenu.Size = new System.Drawing.Size(233, 140);
            this.panelLiga1Submenu.TabIndex = 3;
            // 
            // btnLiga1Mercado
            // 
            this.btnLiga1Mercado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga1Mercado.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga1Mercado.FlatAppearance.BorderSize = 0;
            this.btnLiga1Mercado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga1Mercado.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga1Mercado.Location = new System.Drawing.Point(0, 90);
            this.btnLiga1Mercado.Name = "btnLiga1Mercado";
            this.btnLiga1Mercado.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga1Mercado.Size = new System.Drawing.Size(233, 45);
            this.btnLiga1Mercado.TabIndex = 5;
            this.btnLiga1Mercado.Text = "Mercado";
            this.btnLiga1Mercado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga1Mercado.UseVisualStyleBackColor = false;
            // 
            // btnLiga1TuEquipo
            // 
            this.btnLiga1TuEquipo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga1TuEquipo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga1TuEquipo.FlatAppearance.BorderSize = 0;
            this.btnLiga1TuEquipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga1TuEquipo.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga1TuEquipo.Location = new System.Drawing.Point(0, 45);
            this.btnLiga1TuEquipo.Name = "btnLiga1TuEquipo";
            this.btnLiga1TuEquipo.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga1TuEquipo.Size = new System.Drawing.Size(233, 45);
            this.btnLiga1TuEquipo.TabIndex = 4;
            this.btnLiga1TuEquipo.Text = "Tu equipo";
            this.btnLiga1TuEquipo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga1TuEquipo.UseVisualStyleBackColor = false;
            // 
            // btnLiga1EquiposEnemigos
            // 
            this.btnLiga1EquiposEnemigos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(32)))), ((int)(((byte)(38)))));
            this.btnLiga1EquiposEnemigos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga1EquiposEnemigos.FlatAppearance.BorderSize = 0;
            this.btnLiga1EquiposEnemigos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga1EquiposEnemigos.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga1EquiposEnemigos.Location = new System.Drawing.Point(0, 0);
            this.btnLiga1EquiposEnemigos.Name = "btnLiga1EquiposEnemigos";
            this.btnLiga1EquiposEnemigos.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnLiga1EquiposEnemigos.Size = new System.Drawing.Size(233, 45);
            this.btnLiga1EquiposEnemigos.TabIndex = 3;
            this.btnLiga1EquiposEnemigos.Text = "Equipos enemigos";
            this.btnLiga1EquiposEnemigos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga1EquiposEnemigos.UseVisualStyleBackColor = false;
            // 
            // btnLiga1
            // 
            this.btnLiga1.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLiga1.FlatAppearance.BorderSize = 0;
            this.btnLiga1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLiga1.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLiga1.Location = new System.Drawing.Point(0, 0);
            this.btnLiga1.Name = "btnLiga1";
            this.btnLiga1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnLiga1.Size = new System.Drawing.Size(233, 45);
            this.btnLiga1.TabIndex = 2;
            this.btnLiga1.Text = "Liga 1";
            this.btnLiga1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLiga1.UseVisualStyleBackColor = true;
            // 
            // btnTusLigas
            // 
            this.btnTusLigas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTusLigas.FlatAppearance.BorderSize = 0;
            this.btnTusLigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTusLigas.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTusLigas.Location = new System.Drawing.Point(0, 376);
            this.btnTusLigas.Name = "btnTusLigas";
            this.btnTusLigas.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnTusLigas.Size = new System.Drawing.Size(233, 45);
            this.btnTusLigas.TabIndex = 3;
            this.btnTusLigas.Text = "Tus ligas";
            this.btnTusLigas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTusLigas.UseVisualStyleBackColor = true;
            // 
            // panelGeneralSubmenu
            // 
            this.panelGeneralSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelGeneralSubmenu.Controls.Add(this.btnCalculadoraOfertas);
            this.panelGeneralSubmenu.Controls.Add(this.btnOnceIdealTemporada);
            this.panelGeneralSubmenu.Controls.Add(this.btnOnceIdealJornada);
            this.panelGeneralSubmenu.Controls.Add(this.btnMejoresJugadoresBaratos);
            this.panelGeneralSubmenu.Controls.Add(this.btnMejoresJugadores);
            this.panelGeneralSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelGeneralSubmenu.Location = new System.Drawing.Point(0, 145);
            this.panelGeneralSubmenu.Name = "panelGeneralSubmenu";
            this.panelGeneralSubmenu.Size = new System.Drawing.Size(233, 231);
            this.panelGeneralSubmenu.TabIndex = 2;
            // 
            // btnCalculadoraOfertas
            // 
            this.btnCalculadoraOfertas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCalculadoraOfertas.FlatAppearance.BorderSize = 0;
            this.btnCalculadoraOfertas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalculadoraOfertas.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCalculadoraOfertas.Location = new System.Drawing.Point(0, 180);
            this.btnCalculadoraOfertas.Name = "btnCalculadoraOfertas";
            this.btnCalculadoraOfertas.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnCalculadoraOfertas.Size = new System.Drawing.Size(233, 45);
            this.btnCalculadoraOfertas.TabIndex = 6;
            this.btnCalculadoraOfertas.Text = "Calculadora de ofertas";
            this.btnCalculadoraOfertas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCalculadoraOfertas.UseVisualStyleBackColor = true;
            // 
            // btnOnceIdealTemporada
            // 
            this.btnOnceIdealTemporada.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnOnceIdealTemporada.FlatAppearance.BorderSize = 0;
            this.btnOnceIdealTemporada.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOnceIdealTemporada.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnOnceIdealTemporada.Location = new System.Drawing.Point(0, 135);
            this.btnOnceIdealTemporada.Name = "btnOnceIdealTemporada";
            this.btnOnceIdealTemporada.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnOnceIdealTemporada.Size = new System.Drawing.Size(233, 45);
            this.btnOnceIdealTemporada.TabIndex = 5;
            this.btnOnceIdealTemporada.Text = "Once ideal de la temporada";
            this.btnOnceIdealTemporada.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOnceIdealTemporada.UseVisualStyleBackColor = true;
            // 
            // btnOnceIdealJornada
            // 
            this.btnOnceIdealJornada.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnOnceIdealJornada.FlatAppearance.BorderSize = 0;
            this.btnOnceIdealJornada.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOnceIdealJornada.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnOnceIdealJornada.Location = new System.Drawing.Point(0, 90);
            this.btnOnceIdealJornada.Name = "btnOnceIdealJornada";
            this.btnOnceIdealJornada.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnOnceIdealJornada.Size = new System.Drawing.Size(233, 45);
            this.btnOnceIdealJornada.TabIndex = 4;
            this.btnOnceIdealJornada.Text = "Once ideal de la jornada";
            this.btnOnceIdealJornada.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOnceIdealJornada.UseVisualStyleBackColor = true;
            // 
            // btnMejoresJugadoresBaratos
            // 
            this.btnMejoresJugadoresBaratos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMejoresJugadoresBaratos.FlatAppearance.BorderSize = 0;
            this.btnMejoresJugadoresBaratos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMejoresJugadoresBaratos.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMejoresJugadoresBaratos.Location = new System.Drawing.Point(0, 45);
            this.btnMejoresJugadoresBaratos.Name = "btnMejoresJugadoresBaratos";
            this.btnMejoresJugadoresBaratos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnMejoresJugadoresBaratos.Size = new System.Drawing.Size(233, 45);
            this.btnMejoresJugadoresBaratos.TabIndex = 3;
            this.btnMejoresJugadoresBaratos.Text = "Mejores jugadores baratos";
            this.btnMejoresJugadoresBaratos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMejoresJugadoresBaratos.UseVisualStyleBackColor = true;
            // 
            // btnMejoresJugadores
            // 
            this.btnMejoresJugadores.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMejoresJugadores.FlatAppearance.BorderSize = 0;
            this.btnMejoresJugadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMejoresJugadores.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMejoresJugadores.Location = new System.Drawing.Point(0, 0);
            this.btnMejoresJugadores.Name = "btnMejoresJugadores";
            this.btnMejoresJugadores.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnMejoresJugadores.Size = new System.Drawing.Size(233, 45);
            this.btnMejoresJugadores.TabIndex = 2;
            this.btnMejoresJugadores.Text = "Mejores jugadores";
            this.btnMejoresJugadores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMejoresJugadores.UseVisualStyleBackColor = true;
            // 
            // btnGeneral
            // 
            this.btnGeneral.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGeneral.FlatAppearance.BorderSize = 0;
            this.btnGeneral.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGeneral.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnGeneral.Location = new System.Drawing.Point(0, 100);
            this.btnGeneral.Name = "btnGeneral";
            this.btnGeneral.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnGeneral.Size = new System.Drawing.Size(233, 45);
            this.btnGeneral.TabIndex = 1;
            this.btnGeneral.Text = "General";
            this.btnGeneral.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGeneral.UseVisualStyleBackColor = true;
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(233, 100);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(233, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelChildForm
            // 
            this.panelChildForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildForm.Location = new System.Drawing.Point(250, 0);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(684, 561);
            this.panelChildForm.TabIndex = 1;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.ClientSize = new System.Drawing.Size(934, 561);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.panelSideMenu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(950, 600);
            this.Name = "FormPrincipal";
            this.Text = "Fantasy Insights";
            this.panelSideMenu.ResumeLayout(false);
            this.panelTusLigasSubmenu.ResumeLayout(false);
            this.panelLiga2Submenu.ResumeLayout(false);
            this.panelLiga1Submenu.ResumeLayout(false);
            this.panelGeneralSubmenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        public System.Windows.Forms.Panel panelLogo;
        public System.Windows.Forms.Panel panelGeneralSubmenu;
        public System.Windows.Forms.Button btnGeneral;
        public System.Windows.Forms.Button btnCalculadoraOfertas;
        public System.Windows.Forms.Button btnOnceIdealTemporada;
        public System.Windows.Forms.Button btnOnceIdealJornada;
        public System.Windows.Forms.Button btnMejoresJugadoresBaratos;
        public System.Windows.Forms.Button btnMejoresJugadores;
        public System.Windows.Forms.Panel panelTusLigasSubmenu;
        public System.Windows.Forms.Button btnLiga1;
        public System.Windows.Forms.Panel panelLiga1Submenu;
        public System.Windows.Forms.Button btnLiga1Mercado;
        public System.Windows.Forms.Button btnLiga1TuEquipo;
        public System.Windows.Forms.Button btnLiga1EquiposEnemigos;
        public System.Windows.Forms.Panel panelLiga2Submenu;
        public System.Windows.Forms.Button btnLiga2Mercado;
        public System.Windows.Forms.Button btnLiga2TuEquipo;
        public System.Windows.Forms.Button btnLiga2EquiposEnemigos;
        public System.Windows.Forms.Button btnLiga2;
        public System.Windows.Forms.Button btnTusLigas;
        public System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


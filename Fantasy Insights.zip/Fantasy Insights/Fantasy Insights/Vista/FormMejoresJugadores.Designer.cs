﻿namespace Fantasy_Insights.Vista
{
    partial class FormMejoresJugadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMejoresJugadores));
            this.dataGridViewMejoresJugadores = new System.Windows.Forms.DataGridView();
            this.comboBoxFiltro = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.buttonAdelante = new System.Windows.Forms.Button();
            this.comboBoxFiltroSecundario = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMejoresJugadores)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewMejoresJugadores
            // 
            this.dataGridViewMejoresJugadores.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.dataGridViewMejoresJugadores.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewMejoresJugadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMejoresJugadores.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.dataGridViewMejoresJugadores.Location = new System.Drawing.Point(8, 98);
            this.dataGridViewMejoresJugadores.Name = "dataGridViewMejoresJugadores";
            this.dataGridViewMejoresJugadores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMejoresJugadores.Size = new System.Drawing.Size(497, 349);
            this.dataGridViewMejoresJugadores.TabIndex = 0;
            // 
            // comboBoxFiltro
            // 
            this.comboBoxFiltro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.comboBoxFiltro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxFiltro.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBoxFiltro.FormattingEnabled = true;
            this.comboBoxFiltro.Location = new System.Drawing.Point(9, 71);
            this.comboBoxFiltro.Name = "comboBoxFiltro";
            this.comboBoxFiltro.Size = new System.Drawing.Size(121, 21);
            this.comboBoxFiltro.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(521, 65);
            this.panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(521, 65);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // buttonAtras
            // 
            this.buttonAtras.FlatAppearance.BorderSize = 0;
            this.buttonAtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAtras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAtras.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonAtras.Location = new System.Drawing.Point(349, 71);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(75, 23);
            this.buttonAtras.TabIndex = 3;
            this.buttonAtras.Text = "<--";
            this.buttonAtras.UseVisualStyleBackColor = true;
            // 
            // buttonAdelante
            // 
            this.buttonAdelante.FlatAppearance.BorderSize = 0;
            this.buttonAdelante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdelante.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdelante.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonAdelante.Location = new System.Drawing.Point(430, 71);
            this.buttonAdelante.Name = "buttonAdelante";
            this.buttonAdelante.Size = new System.Drawing.Size(75, 23);
            this.buttonAdelante.TabIndex = 4;
            this.buttonAdelante.Text = "-->";
            this.buttonAdelante.UseVisualStyleBackColor = true;
            // 
            // comboBoxFiltroSecundario
            // 
            this.comboBoxFiltroSecundario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.comboBoxFiltroSecundario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxFiltroSecundario.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBoxFiltroSecundario.FormattingEnabled = true;
            this.comboBoxFiltroSecundario.Location = new System.Drawing.Point(136, 71);
            this.comboBoxFiltroSecundario.Name = "comboBoxFiltroSecundario";
            this.comboBoxFiltroSecundario.Size = new System.Drawing.Size(121, 21);
            this.comboBoxFiltroSecundario.TabIndex = 5;
            // 
            // FormMejoresJugadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(521, 457);
            this.Controls.Add(this.comboBoxFiltroSecundario);
            this.Controls.Add(this.buttonAdelante);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.comboBoxFiltro);
            this.Controls.Add(this.dataGridViewMejoresJugadores);
            this.Name = "FormMejoresJugadores";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "FormMejoresJugadores";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMejoresJugadores)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridViewMejoresJugadores;
        public System.Windows.Forms.ComboBox comboBoxFiltro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Button buttonAtras;
        public System.Windows.Forms.Button buttonAdelante;
        public System.Windows.Forms.ComboBox comboBoxFiltroSecundario;
    }
}
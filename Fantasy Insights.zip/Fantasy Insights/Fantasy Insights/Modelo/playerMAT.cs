﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fantasy_Insights.Modelo
{
    public partial class playerMAT
    {
        public string nombreJugador { get; set; }
        public string nombreEquipo { get; set; }
        public string posicionJugador { get; set; }
        public int? valor {  get; set; }
        public double? puntos { get; set; }
        public playerMAT(player p)
        {
            nombreJugador = p.nombreJugador;
            nombreEquipo = p.nombreEquipo;
            posicionJugador = p.posicionJugador;
            valor = p.valorMercadoReciente;
            puntos = p.puntosTotales;
        }
    }
}

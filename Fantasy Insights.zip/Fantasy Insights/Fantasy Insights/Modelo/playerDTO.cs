﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fantasy_Insights.Modelo
{
    public partial class playerDTO
    {
        public string nombreJugador { get; set; }
        public string nombreEquipo { get; set; }
        public string posicionJugador { get; set; }
        public Nullable<double> puntosTotales { get; set; }
        public Nullable<double> puntosPromedio { get; set; }
        public Nullable<int> valorMercadoReciente { get; set; }
        public playerDTO(player p)
        {
            nombreJugador = p.nombreJugador;
            nombreEquipo = p.nombreEquipo;
            posicionJugador = p.posicionJugador;
            puntosTotales = p.puntosTotales;
            puntosPromedio = p.puntosPromedio;
            valorMercadoReciente = p.valorMercadoReciente;
        }
    }
}

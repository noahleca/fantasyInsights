﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fantasy_Insights.Modelo
{
    public partial class playerMAJ
    {
        public string nombreJugador { get; set; }
        public string nombreEquipo { get; set; }
        public string posicionJugador { get; set; }
        public int? valor { get; set; }
        public int? weekNumber {  get; set; }
        public int? weekPoints { get; set; }
        public playerMAJ(player p)
        {
            nombreJugador = p.nombreJugador;
            nombreEquipo = p.nombreEquipo;
            posicionJugador = p.posicionJugador;
            valor = p.valorMercadoReciente;
            weekNumber = p.weekNumber;
            weekPoints = p.weekPoints;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fantasy_Insights.Modelo
{
    public class Repository
    {
        fantasyInsightsEntities db;

        List<lineup> listaLineups;
        List<playerMAJ> listaMAJ;
        List<playerMAT> listaMAT;

        public Repository()
        {
            DbConnect();
            listaLineups = GetAlineaciones();
            listaMAJ = GetMejorAlineacionJornada();
            listaMAT = GetMejorAlineacionTemporada();
        }
        public List<playerMAJ> GetPlayersMAJ()
        {
            return listaMAJ;
        }
        public List<playerMAT> GetPlayersMAT()
        {
            return listaMAT;
        }
        void DbConnect()
        {
            db = new fantasyInsightsEntities();
        }
        public List<string> GetNombreEquipos()
        {
            List<string> nombreEquipos = db.players.OrderBy(p => p.nombreEquipo).Select(p => p.nombreEquipo).Distinct().ToList();
            return nombreEquipos;
        }
        public List<playerMAT> GetMejorAlineacionTemporada()
        {
            List<player> mejorAlineacion = new List<player>();
            List<playerMAT> lpm = new List<playerMAT>();
            int mejorPuntaje = 0;

            foreach (var lineup in listaLineups)
            {
                List<player> alineacionActual = new List<player>();
                var portero = db.players.Where(p => p.posicionJugador.Equals("portero")).OrderByDescending(p => p.puntosTotales).Take((int)lineup.numeroPorteros).ToList();
                var defensas = db.players.Where(p => p.posicionJugador.Equals("defensa")).OrderByDescending(p => p.puntosTotales).Take((int)lineup.numeroDefensas).ToList();
                var centrocampistas = db.players.Where(p => p.posicionJugador.Equals("centrocampista")).OrderByDescending(p => p.puntosTotales).Take((int)lineup.numeroCentrocampistas).ToList();
                var delanteros = db.players.Where(p => p.posicionJugador.Equals("delantero")).OrderByDescending(p => p.puntosTotales).Take((int)lineup.numeroDelanteros).ToList();

                alineacionActual.AddRange(portero);
                alineacionActual.AddRange(defensas);
                alineacionActual.AddRange(centrocampistas);
                alineacionActual.AddRange(delanteros);

                int puntajeAlineacionActual = (int)alineacionActual.Sum(p => p.weekPoints);

                if (puntajeAlineacionActual > mejorPuntaje)
                {
                    mejorPuntaje = puntajeAlineacionActual;
                    mejorAlineacion = alineacionActual;
                }
            }
            foreach (var jugador in mejorAlineacion)
            {
                playerMAT pm = new playerMAT(jugador);
                lpm.Add(pm);
            }
            return lpm;
        }
        public List<playerMAJ> GetMejorAlineacionJornada()
        {
            List<player> mejorAlineacion = new List<player>();
            List<playerMAJ> lpm = new List<playerMAJ>();
            int mejorPuntaje = 0;

            foreach (var lineup in listaLineups)
            {
                List<player> alineacionActual = new List<player>();
                var portero = db.players.Where(p => p.posicionJugador.Equals("portero")).OrderByDescending(p => p.weekNumber).ThenByDescending(p => p.weekPoints).Take((int)lineup.numeroPorteros).ToList();
                var defensas = db.players.Where(p => p.posicionJugador.Equals("defensa")).OrderByDescending(p => p.weekNumber).ThenByDescending(p => p.weekPoints).Take((int)lineup.numeroDefensas).ToList();
                var centrocampistas = db.players.Where(p => p.posicionJugador.Equals("centrocampista")).OrderByDescending(p => p.weekNumber).ThenByDescending(p => p.weekPoints).Take((int)lineup.numeroCentrocampistas).ToList();
                var delanteros = db.players.Where(p => p.posicionJugador.Equals("delantero")).OrderByDescending(p => p.weekNumber).ThenByDescending(p => p.weekPoints).Take((int)lineup.numeroDelanteros).ToList();

                alineacionActual.AddRange(portero);
                alineacionActual.AddRange(defensas);
                alineacionActual.AddRange(centrocampistas);
                alineacionActual.AddRange(delanteros);

                int puntajeAlineacionActual = (int)alineacionActual.Sum(p => p.weekPoints);

                if (puntajeAlineacionActual > mejorPuntaje)
                {
                    mejorPuntaje = puntajeAlineacionActual;
                    mejorAlineacion = alineacionActual;
                }
            }

            foreach (var jugador in mejorAlineacion)
            {
                playerMAJ pm = new playerMAJ(jugador);
                lpm.Add(pm);
            }
            return lpm;
        }
        public List<lineup> GetAlineaciones()
        {
            List<lineup> lineups = db.lineups.ToList();
            return lineups;
        }
        public List<playerDTO> GetMejoresJugadoresFiltrados(string filtroPrimario, string filtroSecundario)
        {
            var query = db.players.Where(p => p.puntosPromedio > 5);

            if (filtroSecundario != "-")
            {
                query = query.Where(p => p.nombreEquipo.Equals(filtroSecundario));
            }

            switch (filtroPrimario)
            {
                case "nombreJugador":
                    query = query.OrderBy(p => p.nombreJugador);
                    break;
                case "nombreEquipo":
                    query = query.OrderBy(p => p.nombreEquipo);
                    break;
                case "posicionJugador":
                    query = query.OrderBy(p => p.posicionJugador);
                    break;
                case "puntosTotales":
                    query = query.OrderByDescending(p => p.puntosTotales);
                    break;
                case "puntosPromedio":
                    query = query.OrderByDescending(p => p.puntosPromedio);
                    break;
                case "valorMercadoReciente":
                    query = query.OrderByDescending(p => p.valorMercadoReciente);
                    break;
            }

            var playerDTOList = query
                .AsEnumerable() // Aplicar ToList() al final para traer los datos a memoria
                .Select(p => new playerDTO(p))
                .ToList();

            return playerDTOList;
        }
        public List<playerDTO> GetMejoresJugadoresBaratosFiltrados(string filtroPrimario, string filtroSecundario)
        {
            var query = db.players.Where(p => p.puntosPromedio > 4).Where(p => p.valorMercadoReciente < 20000000);

            if (filtroSecundario != "-")
            {
                query = query.Where(p => p.nombreEquipo.Equals(filtroSecundario));
            }

            switch (filtroPrimario)
            {
                case "nombreJugador":
                    query = query.OrderBy(p => p.nombreJugador);
                    break;
                case "nombreEquipo":
                    query = query.OrderBy(p => p.nombreEquipo);
                    break;
                case "posicionJugador":
                    query = query.OrderBy(p => p.posicionJugador);
                    break;
                case "puntosTotales":
                    query = query.OrderByDescending(p => p.puntosTotales);
                    break;
                case "puntosPromedio":
                    query = query.OrderByDescending(p => p.puntosPromedio);
                    break;
                case "valorMercadoReciente":
                    query = query.OrderByDescending(p => p.valorMercadoReciente);
                    break;
            }

            var playerDTOList = query
                .AsEnumerable() // Aplicar ToList() al final para traer los datos a memoria
                .Select(p => new playerDTO(p))
                .ToList();

            return playerDTOList;
        }
    }
}
